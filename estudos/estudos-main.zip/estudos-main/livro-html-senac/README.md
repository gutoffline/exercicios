Link para os arquivos que seram utilizados durante as atividades do livro:

editorasenacsp.com.br/informatica/html5-css3/atividades.zip


Internet
- 1960
- Guerra Fria
- Primeiro bases militares, depois (1970 - 1980) faculdades
- Tim Berners-Lee WWW, URL, HTTP, HTML

HTML
- Nosso cérebro funciona por associações, e essa é a base da web: criar ligações por meio de links ou hyperlinks.
- HTML - Hyper Text Markutp Language
- XML - Extensible Markup Language
- HTML + XML = XHTML
- W3C
- XHTML chega em 2000
- HTML5 chega em 2012

http://www.evolutionoftheweb.com/?hl=pt-br



ORGANIZAÇÃO
- em pastas por tipo (css, js, images, videos, icones)

galeria-de-fotos.html
historia-empresa.html

https://www.sp.senac.br/senac-americana/cursos-livres/curso-de-reiki-master -> URL Amigável (SEO)

index.html
css -> estilos.css
css -> reset.css
css -> tabelas.css
js -> funcoes.js
imagens


Briefing
- Entendimento inicial do projeto, identificar os objetivos, pessoas chave, expectavitvas

Arquitetura da Informação
- Mapa do Site e Wireframe 
- Acessibilidade, Usabilidade, Navegabilidade


HTML - 1991
HTML5 - 2012

Sintaxe --> forma de escrever algo

<tag>Conteúdo</tag>
<p>Guto Xavier</p>

case-sensitive --> diferenciação de maiúsculas e minúsculas
HTML não é case sensitive, porém a escrita semântica recomenda sempre escrever as tags em letra minúsculas 
<p></p>

Javascript é case sensitive, Document é diferente de document


Atributos entre aspas
<p id="texto"></p>
<img src="imagem.jpg">


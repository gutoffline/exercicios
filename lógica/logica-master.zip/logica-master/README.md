# Lógica de Programação
Conteúdo do curso de lógica de programação
- Exercícios
- Exemplos
- Materiais
- Links

  - [Curso em vídeo - Lógica de Programação](https://www.youtube.com/watch?v=8mei6uVttho&list=PLHz_AreHm4dmSj0MHol_aoNYCSGFqvfXV)
  - [VisualG](https://sourceforge.net/projects/visualg30/)
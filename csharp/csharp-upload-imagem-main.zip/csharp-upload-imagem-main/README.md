# csharp-upload-imagem
Upload de imagem feito em C#  - Widows Forms

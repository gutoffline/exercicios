function entrar(){
    alert("Então você quer entrar?");

    let usuario = document.querySelector("#usuario").value;

    alert(usuario + " esse é você?");

    let nome = prompt("Coloque seu nome de verdade: ", "Escreva aqui");

}
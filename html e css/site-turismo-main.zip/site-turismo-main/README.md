Github --> portifólio de desenvolvedor, repositórios

Github --> versionamento de arquivos


! + ENTER --> Estrutura padrão do HTML

CTRL + N --> Cria um arquivo novo

CTRL + S --> Salva o arquivo

ALT + SHIFT + F --> organiza o HTML

CTRL + SHIFT + P --> paleta de comandos do vscode
Live Server: Open With Live Server

ALT + Z --> Quebra linha dentro do vscode

CTRL + ; --> Comenta o código

# comportamentos

- :hover --> ao passar o mouse
- :focus --> elemento focado
- :visited --> links que ja foram visitados
- :active --> link que está sendo clicado no momento

source 

# Barbearia Só Barba
Site para a barbearia Só Barba. 

Projeto desenvolvido para estudo no curso de ***Desenvolvedor Web*** no *Senac Americana*.

O Objetivo desse projeto é praticar os conceitos iniciais de **HTML** e **CSS**.

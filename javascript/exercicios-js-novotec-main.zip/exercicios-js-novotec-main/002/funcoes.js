function apertou(){
    let n1 = document.getElementById("numero").value
    document.getElementById("mensagem").innerText = "O número informado foi " + n1

}
//array
let filmes = ["soul.jpg" , "300.jpg" , "simplesmente-acontece.jpg"];

for(let i = 0; i < filmes.length; i++){
    document.write("<img src=img/" + filmes[i] + ">");
}
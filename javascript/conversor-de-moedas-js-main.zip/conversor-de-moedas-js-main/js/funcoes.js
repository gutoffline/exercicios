let valorEmDolar = parseFloat(prompt("Qual o valor em dólar que você quer converter?"));
let valorEmReal = valorEmDolar * 5.77;
let valorEmRealFixado = valorEmReal.toFixed(2);
alert(valorEmRealFixado);
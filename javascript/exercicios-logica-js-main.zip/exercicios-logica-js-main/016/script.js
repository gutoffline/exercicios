// Faça um Programa que peça um valor e mostre na tela se o valor é positivo ou negativo.

let valor
console.log("Informe um valor numérico")
valor = 77.55

if(valor >= 0){
    console.log("Positivo")
}else{
    console.log("Negativo")
}

function alo(){
    /*
    saída de dados
    no corpo do navegador:
    document.write("alo mundo")

    em uma div, span, h1, etc:
    document.querySelector("#resultado").innerHTML = "Alo mundo"

    em um campo de texto:
    document.querySelector("#resultado").value = "Alo Mundo"
    */
    document.querySelector("#resultado").value = "Alo Mundo"
}

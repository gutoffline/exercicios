function exibir(n1 = 0) {
    document.querySelector("#resultado").innerHTML = "O número informado foi " + n1
}

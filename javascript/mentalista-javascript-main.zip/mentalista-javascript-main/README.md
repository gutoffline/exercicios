# mentalista-javascript
Jogo de adivinhação de número

console.log("Olá, Mundo");

/* ADIÇÃO */
console.log("12 + 13");
console.log(12+13);

/* MULTIPLICAÇÃO */
console.log("14 + 3");
console.log(14 + 3);

/* SUBTRAÇÃO */
console.log("10 - 4");
console.log(10 - 4);

/* DIVISÃO */
console.log("25 / 5");
console.log(25 / 5);

/* MÓDULO */
console.log("23 % 2");
console.log(23 % 2);


var curso = "Desenvolvimento Front-End";
console.log(curso);














// var c = 1 
// while(c <= 6){
//     console.log(`Passo ${c}`)
//     c++
// }

console.log('Vai começar')
for(var c = 1; c <= 10; c++){
    console.log(`Passo ${c}`)
}

console.log('Vai terminar')
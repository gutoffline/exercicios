function parimpar(n){
    if(n%2 == 0){
        return 'Par!'
    }else{
        return 'Ímpar!'
    }
}

console.log(parimpar(223))
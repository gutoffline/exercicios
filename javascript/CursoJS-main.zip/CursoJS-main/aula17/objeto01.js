let amigo = {
    nome:'José',
    sexo: 'M',
    peso: 85.5,
    engordar(p){
        console.log('Engordou')
        this.peso += p
    }
}

console.log(amigo)

amigo.engordar(10)

console.log(amigo)
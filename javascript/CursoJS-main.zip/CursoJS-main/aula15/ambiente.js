let num = [5, 8, 2 , 9, 3]
console.log(num)
num.sort()
console.log(num)
num.push(1)
console.log(num)
num.sort()
console.log(num)

// for (var i = 0; i < num.length; i++){
//     console.log(num[i])
// }

// num.forEach(element => {
//    console.log(element)  
// });


for (let i in num) {
    console.log(i)
}
// Tipos de dados
/*
string --> texto
números
    int --> número inteiro
    float --> número fracionais
booleano --> Verdadeiro (true) ou Falso (false)
*/

let nome = "Guto" // string
let idade = 36 // number (int)
let altura = 1.75 // number(float)
let empregado = true // boolean

console.log(nome)
console.log(typeof nome)

console.log(idade)
console.log(typeof idade)

console.log(altura)
console.log(typeof altura)

console.log(empregado)
console.log(typeof empregado)
console.log("Olá mundo")

// operadores matemáticos +(adição) -(subtração) /(divisão) *(multiplicação)

// variáveis
nome = "guto"
console.log(nome)

var nome = "guto xavier"
console.log(nome)

let nome1 = "guto rodrigo"
console.log(nome1)

//constantes
const sobrenome = "xavier"
console.log(sobrenome)
// sobrenome = "souza"

//vamos usar
let email = "gutoffline@gmail.com"
const empresa = "Senac"

let n1 = 20
let n2 = 10

console.log(n1+n2)
console.log(n1-n2)
console.log(n1/n2)
console.log(n1*n2)

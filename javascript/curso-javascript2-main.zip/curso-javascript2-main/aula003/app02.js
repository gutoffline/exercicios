let i = 0 
// while(i < 0){
//     console.log("Vitória")
//     i++
// }

do {
    console.log("Vitória")
    i++
} while (i < 0);
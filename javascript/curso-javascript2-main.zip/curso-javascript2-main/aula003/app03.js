let frutas = ["🍓","🍋","🍉","🍇"]
let i = 0
for(i = 0; i < 4; i++){
    console.log(frutas[i])
}


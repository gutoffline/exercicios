// console.log("🍓")
// console.log("🍋")
// console.log("🍉")
// console.log("🍇")
let frutas = ["🍓","🍋","🍉","🍇"]
let i = 0 
while(i < 4){
    console.log(frutas[i])
    i++
}

console.log(i)
// estrutura de decisão if
/*

if(condição){
    RESPOSTA VERDADEIRA
}else{
    RESPOSTA FALSA
}

*/

let salario = 2000
if(salario > 1903){
    console.log("Ahhh RECEBA!")
}else if(salario > 1000){
    console.log("Ta quase lá")
}else{
    console.log("aproveite enquanto pode")
}

clientes = "João Paulo Pedro Maria"
lista_clientes = clientes.split()
print(lista_clientes)
print(len(lista_clientes))

print(lista_clientes[0][0])
print(lista_clientes[1][0])
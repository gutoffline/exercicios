# Operadores Relacionais
print(10 > 3)

# > --> maior
# < --> menor
# >= --> maior ou igual
# <= --> menor ou igual
# != --> diferente
# == --> igual
# IMPORTANTE
# == é o operador de comparação
# = é o operador de atribuição

print( 5+2 > 10)
# ______ > ______ ---> True / False
print("10 < 10", 10<10)
print("10 == 10", 10==10)
print("10 <= 10", 10<=10)
#Faça um Programa que verifique se uma letra digitada é vogal ou consoante. 
letra = input("Informe uma letra")
letra = letra.upper()
if letra == "A":
    print("Vogal")
elif letra == "E":
    print("Vogal")
elif letra == "I":
    print("Vogal")
elif letra == "O":
    print("Vogal")
elif letra == "U":
    print("Vogal")
else:
    print("Consoante")

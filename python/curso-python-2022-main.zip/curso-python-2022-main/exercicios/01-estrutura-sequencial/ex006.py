# Faça um Programa que peça o raio de um círculo, calcule e mostre sua área. 

import math

raio = float(input('Informe o raio do círculo: '))
area = math.pi * raio ** 2
print('A área do círculo é:', area)
# Faça um Programa que peça as 4 notas bimestrais e mostre a média. 
n1 = input("Informe a primeira nota ")
n2 = input("Informe a segunda nota ")
n3 = input("Informe a terceira nota ")
n4 = input("Informe a quarta nota ")
n1 = float(n1)
n2 = float(n2)
n3 = float(n3)
n4 = float(n4)
media = (n1 + n2 +n3 + n4) / 4
print("Sua média é" , media)
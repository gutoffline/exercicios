# Faça um Programa que peça um número e então mostre a mensagem O número informado foi [número]. 
n1 = input('Informe um número: ')
print('O número informado foi', n1)
# Faça um Programa que mostre a mensagem "Alo mundo" na tela. 
print("Alo mundo")

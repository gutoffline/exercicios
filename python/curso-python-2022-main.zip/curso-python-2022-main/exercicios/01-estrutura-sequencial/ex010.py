# Faça um Programa que peça a temperatura em graus Celsius, transforme e mostre em graus Fahrenheit. 
c = float(input('Informe a temperatura em Celsius: '))
f = 1.8 * c + 32
print('Fahrenheit:', f)
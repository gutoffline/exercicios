# Faça um programa que converta metros em centímetros
metros = input("Informe um valor em metros ")
metros = float(metros)
cm = metros * 100
print(metros, "metro(s) equivale à", cm , "centímetro(s)")

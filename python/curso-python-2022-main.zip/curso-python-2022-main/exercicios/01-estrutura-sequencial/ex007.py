# Faça um Programa que calcule a área de um quadrado, em seguida mostre o dobro desta área para o usuário. 
lado = float(input("Informe o valor de um lado: "))
area = lado * lado
dobro = area * 2
print("O dobro da área é:", dobro)
print("Atividade 01")
print(10+2)
nome = input("Qual seu nome? ")
print("Bom dia", nome)

# limpar o terminal: clear
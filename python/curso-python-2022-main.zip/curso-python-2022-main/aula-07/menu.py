from os import system
def exibir_menu():
    system("cls")
    print("Escolha a operação")
    print("1 - Adição (+)")
    print("2 - Subtração (-)")
    print("3 - Divisão (/)")
    print("4 - Multiplicação (*)")

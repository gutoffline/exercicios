# salvar como operacoes.py
def soma(n1=0,n2=0):
    resultado = n1 + n2
    print(resultado)
    
def subtrair(n1,n2):
    resultado = n1 - n2
    print(resultado)

def dividir(n1,n2):
    resultado = n1/n2
    print(resultado)
    
def multiplicar(n1,n2):
    resultado = n1*n2
    print(resultado)


#ESTRUTURA DE DECISÃO
"""
if teste lógico :
    resposta verdadeira
    resposta verdadeira

if teste lógico :
    resposta verdadeira
else:
    reposta falsa
"""
idade = 15
if idade >= 18:
    print("Parabéns, você pode iniciar suas aulas de direção")
else:
    print("Você ainda não pode inicar conosco.")


#operadores relacionais
print(10>10) #false
print(10>=10) #true
print(10==10) #true
print(10<10) #false
print(10<=10) #true
print(10!=10) #false
print("10" == "10") #true
print("10" == 10) #false
print(int("10") == 10) #true
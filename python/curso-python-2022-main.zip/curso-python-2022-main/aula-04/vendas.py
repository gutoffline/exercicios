valor = float(input("Informe o valor vendido: "))
if valor < 1000:
    print("Calculadora")
elif valor < 10000:
    print("Notebook")
else:
    print("Iphone")
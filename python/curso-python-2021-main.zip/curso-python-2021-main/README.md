# Curso de Python 2021
Conteúdo e exemplos desenvolvidos no curso de Python I - Fundamentos do Senac Americana de 2021.
Curso iniciado em Setembro/2021

"""
for x in range(10):
    print(x)

for x in range(20, 30):
    print(x)

for x in range(10,100,5):
    print(x)

for x in range(10,1,-1):
    print(x)

print(range(10))

"""
frutas = ["maçã", "laranja", "banana", "morango"]
for x in range(len(frutas)):
    print(frutas[x])

for fruta in frutas:
    print(fruta)

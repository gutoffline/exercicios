#import funcionarios
import clientes
#from bibliotecas import produtos

print("Início do programa")

clientes.cadastro()

print("Fim do programa")





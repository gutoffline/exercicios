def ExibirMenu():
    print("SISTEMA DE GESTÃO ESCOLAR")
    print("=========================")
    print("Escolha uma das opções:")
    print("1 - Cadastro de alunos")
    print("2 - Relatório de alunos")
    print("3 - Cadastro de matérias")
    print("4 - Relatório de matérias")
    print("5 - Finalizar")
    opcao = int(input("Informe a opção escolhida: "))
    return opcao
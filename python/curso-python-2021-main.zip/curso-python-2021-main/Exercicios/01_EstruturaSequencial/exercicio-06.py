import math

raio = int(input("Informe a medida do raio de um circulo: "))
area = 2*math.pi*raio
print ("A area do circulo de raio", raio, "é", area)

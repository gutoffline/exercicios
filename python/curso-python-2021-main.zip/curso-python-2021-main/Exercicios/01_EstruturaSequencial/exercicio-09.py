farenheit = int(input('Informe a temperatura em Farenheit: '))
celsius = 5 * (farenheit - 32) / 9.0
print("A temperatura em Celsius é", celsius)

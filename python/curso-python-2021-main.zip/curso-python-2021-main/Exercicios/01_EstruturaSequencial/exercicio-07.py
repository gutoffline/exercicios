lado = int(input("Informe a medida do lado de um quadrado: "))
area = lado * lado
print("A area do quadrado de lado", lado, "é", area)
print("O dobro da area é", 2*area)

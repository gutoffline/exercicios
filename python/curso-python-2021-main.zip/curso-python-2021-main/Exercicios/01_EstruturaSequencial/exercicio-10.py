celsius = int(input('Informe a temperatura em Celsius: '))
farenheit = ((celsius / 5.0) * 9.0) + 32.0

print ("A temperatura em Farenheit é", farenheit)

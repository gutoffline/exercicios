numero = int(input("Informe um numero: "))
print("O numero informado foi:", numero)

valorPorHora = int(input('Qual o valor da sua hora trabalhada: '))
horas = int(input('Informe a quantidade de horas trabalhadas: '))
salario = valorPorHora * horas
print('Seu salario neste mes sera', salario)

numero_dia = int(raw_input('Informe um numero para saber o dia da semana: '))

if (numero_dia == 1):
    print 'Domingo'
elif (numero_dia == 2):
    print 'Segunda'
elif (numero_dia == 3):
    print 'Terca'
elif (numero_dia == 4):
    print 'Quarta'
elif (numero_dia == 5):
    print 'Quinta'
elif (numero_dia == 6):
    print 'Sexta'
elif (numero_dia == 7):
    print 'Sabado'
else:
    print 'Valor invalido'

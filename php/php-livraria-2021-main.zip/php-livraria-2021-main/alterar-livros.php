<?php
$nome = "";
$categoria = "";
$foto = "";
$preco = "";

if (isset($_POST['categoria'])) {
    $categoria = $_POST['categoria'];
    $nome = $_POST['nome'];
    $foto = $_POST['foto'];
    $preco = $_POST['preco'];
    $id = $_POST['id'];

    include "conexao.php";
    
    $sqlAlterar = "UPDATE tb_livros SET
                    titulo = '{$nome}' , 
                    categoria = '{$categoria}' ,
                    capa = '{$foto}' , 
                    preco = '{$preco}'
                    WHERE id = {$id}
                    ";
    print_r($sqlAlterar);
    exit();
    $resultado = mysqli_query($conexao , $sqlAlterar);

    if($resultado){
        header('Location:todos-livros.php');
    }else{
        echo "Houve algum problema.";
    }
}
<nav>
    <a href="index.php">Novo livro</a>
    <a href="todos-livros.php">Todos os livros</a>
    <a href="#">Pesquisa de livro</a>
</nav>
<?php

$id_livro = $_GET["id"];

include "conexao.php";
$sqlExcluir = "DELETE FROM tb_livros WHERE id = {$id_livro}";
$resultado = mysqli_query($conexao , $sqlExcluir);
if($resultado){
    header('Location: todos-livros.php');
}else{
    echo "Houve algum erro";
}

?>
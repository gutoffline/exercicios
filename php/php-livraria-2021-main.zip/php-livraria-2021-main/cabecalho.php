<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aula</title>
    <link href="estilo.css" rel="stylesheet">
</head>

<body>
    <header>
        <h1><img src="livros.png">BookNet</h1>
        <h2>Sua livraria online</h2>
    </header>
<?php
$nome = "";
$categoria = "";
$foto = "";
$preco = "";

if (isset($_POST['categoria'])) {
    $categoria = $_POST['categoria'];
    $nome = $_POST['nome'];
    $foto = $_POST['foto'];
    $preco = $_POST['preco'];

    include "conexao.php";
    $sqlInserir = "INSERT INTO tb_livros(titulo, categoria, capa, preco) values('{$nome}' , '{$categoria}' , '{$foto}' , '{$preco}')";

    $resultado = mysqli_query($conexao , $sqlInserir);

    if($resultado){
        header('Location:todos-livros.php');
    }else{
        echo "Houve algum problema.";
    }
}
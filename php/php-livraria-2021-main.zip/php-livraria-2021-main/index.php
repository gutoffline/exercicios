<?php include "cabecalho.php" ?>
<?php include "menu.php" ?>
<form name="formulario-livros" method="post" action="cadastrar-livros.php">
    <p>
        <lable>Nome do livro:</label>
            <input name="nome" required>
    </p>
    <p>
        <label>Categoria:</label>
        <select name="categoria">
            <option value="aventura">Aventura</option>
            <option value="biografia">Biografia</option>
            <option value="ficção">Ficção científica</option>
        </select>
    </p>
    <p>
        <label>Foto:</label>
        <input name="foto">
    </p>
    <p>
        <label>Preço:</label>
        <input name="preco">
    </p>
    <p>
        <button type="submit">Cadastrar</button>
    </p>
</form>
<?php include "menu.php" ?>
<?php include "rodape.php" ?>
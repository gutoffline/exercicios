<?php

/* CONEXÃO COM BANCO DE DADOS */
$servidor_bd = "localhost";
$usuario_bd = "root";
$senha_bd = "";
$banco = "bdlivraria";

$conexao = mysqli_connect($servidor_bd , $usuario_bd , $senha_bd , $banco);
if(!$conexao){
    die("<h3>Não conectou. Erro: " . mysqli_connect_error());
}

?>
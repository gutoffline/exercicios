<?php include "cabecalho.php" ?>
<?php include "menu.php" ?>
<?php

include "conexao.php";
$sqlBusca = "SELECT * FROM tb_livros";
$listaDeLivros = mysqli_query($conexao , $sqlBusca);

?>
<div class="lista-livros">

    <?php 
    while($linhaLivro = mysqli_fetch_assoc($listaDeLivros)){
    ?>
        <div class="livro">
            <h3><?php echo $linhaLivro["titulo"] ; ?></h3>
            <p>
                <a href="excluir-livro.php?id=<?php echo $linhaLivro["id"];?>">[EXCLUIR]</a>

                <a href="formulario-alterar-livro.php?id=<?php echo $linhaLivro["id"];?>">[ALTERAR]</a>
            </p>
            <h4><?php echo $linhaLivro["categoria"] ; ?></h4>
            <img src="<?php echo $linhaLivro["capa"] ; ?>">
            <h4>
                <s>R$ <?php echo $linhaLivro["preco"] ; ?></s>
                <?php
                $precoLivro = $linhaLivro["preco"];
                $desconto = $precoLivro * 0.1;
                $precoComDesconto = $precoLivro - $desconto;

                if($precoComDesconto > 39.99){
                    echo  39.99;
                }else{
                    echo $precoComDesconto;
                }
                ?>
            </h4>
        </div>
        <?php
    }
    ?>
</div>
<?php include "menu.php" ?>
<?php include "rodape.php" ?>
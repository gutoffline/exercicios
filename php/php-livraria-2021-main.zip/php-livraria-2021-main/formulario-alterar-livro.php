<?php
include "cabecalho.php";
include "menu.php";
$id_livro = $_GET['id'];

include "conexao.php";
$sqlBuscar = "SELECT * FROM tb_livros WHERE id = {$id_livro}";
$resultado = mysqli_query($conexao , $sqlBuscar);

$titulo = $categoria = $capa = $preco = "";

while($livro = mysqli_fetch_assoc($resultado)){
    $titulo = $livro['titulo'];
    $categoria = $livro['categoria'];
    $capa = $livro['capa'];
    $preco = $livro['preco'];
}
?>
<form name="formulario-livros" method="post" action="alterar-livros.php">
<input type="hidden" name="id" value="<?php echo $id_livro;?>">
    <p>
        <lable>Nome do livro:</label>
        <input name="nome" required value="<?php echo $titulo; ?>">
    </p>
    <p>
        <label>Categoria:</label>
        <select name="categoria">
            <option value="aventura" <?php if($categoria == "aventura") echo "selected" ; ?>>Aventura</option>
            <option value="biografia" <?php if($categoria == "biografia") echo "selected" ; ?>>Biografia</option>
            <option value="ficção" <?php if($categoria == "ficção") echo "selected" ; ?>>Ficção científica</option>
            <option value="fantasia"  <?php if($categoria == "fantasia") echo "selected" ; ?>>Fantasia</option>
        </select>
    </p>
    <p>
        <label>Foto:</label>
        <input name="foto" value="<?php echo $capa; ?>">
    </p>
    <p>
        <label>Preço:</label>
        <input name="preco" value="<?php echo $preco; ?>">
    </p>
    <p>
        <button type="submit">Cadastrar</button>
    </p>
</form>

<?php
include "menu.php";
include "rodape.php";
?>
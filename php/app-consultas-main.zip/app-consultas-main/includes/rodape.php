<footer>
            &copy; Todos os direitos reservados
        </footer>
    </main>
    <script src="../bootstrap/js/bootstrap.bundle.js"></script>
    <script src="../js/jquery.min.js"></script>
</body>
</html>